﻿namespace DentalBackend.Data
{
    public class ApplicationUserRole
    {
        public long Id { get; set; }
        public long UserId { get; set; } //userId
        public int RoleId { get; set; }
    }
}
